from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
from app.models.base import Base

class Document(Base):
    __tablename__ = "documents"
    
    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(String, unique=True, index=True) # UUID or similar
    title = Column(String, index=True)
    company_name = Column(String, index=True)
    document_type = Column(String, index=True) # invoice/report/contract
    uploaded_by = Column(String, index=True) # Could be user ID or username
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    file_path = Column(String) # For local or S3 storage reference
