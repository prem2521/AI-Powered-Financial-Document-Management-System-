from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.models.user import Role, User
from pydantic import BaseModel
from typing import List
from app.auth.dependencies import get_current_active_user, RoleChecker

router = APIRouter(prefix="/roles", tags=["roles"])

class RoleCreate(BaseModel):
    name: str

class RoleResponse(BaseModel):
    id: int
    name: str
    class Config:
        from_attributes = True

allow_create_role = RoleChecker(["Admin"])

@router.post("/create", response_model=RoleResponse)
def create_role(role: RoleCreate, db: Session = Depends(get_db), current_user: User = Depends(allow_create_role)):
    db_role = db.query(Role).filter(Role.name == role.name).first()
    if db_role:
        raise HTTPException(status_code=400, detail="Role already exists")
    
    new_role = Role(name=role.name)
    db.add(new_role)
    db.commit()
    db.refresh(new_role)
    return new_role
