from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.models.user import Role, User
from pydantic import BaseModel
from typing import List
from app.auth.dependencies import get_current_active_user, RoleChecker

router = APIRouter(prefix="/users", tags=["users"])

class RoleAssign(BaseModel):
    user_id: int
    role_name: str

class RoleResponse(BaseModel):
    id: int
    name: str
    class Config:
        from_attributes = True

allow_assign_role = RoleChecker(["Admin"])

@router.post("/assign-role")
def assign_role(assignment: RoleAssign, db: Session = Depends(get_db), current_user: User = Depends(allow_assign_role)):
    user = db.query(User).filter(User.id == assignment.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
        
    role = db.query(Role).filter(Role.name == assignment.role_name).first()
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
        
    if role in user.roles:
        return {"message": "Role already assigned"}
        
    user.roles.append(role)
    db.commit()
    return {"message": "Role assigned successfully"}

@router.get("/{id}/roles", response_model=List[RoleResponse])
def get_user_roles(id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user.roles

@router.get("/{id}/permissions")
def get_user_permissions(id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
        
    # For simplicity, permissions are tied directly to roles in this implementation
    roles = [role.name for role in user.roles]
    permissions = []
    if "Admin" in roles:
        permissions.append("full_access")
    if "Financial Analyst" in roles:
        permissions.append("upload_edit")
    if "Auditor" in roles:
        permissions.append("review")
    if "Client" in roles:
        permissions.append("view_only")
        
    return {"permissions": permissions}
