from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.models.document import Document
from app.models.user import User
from app.auth.dependencies import get_current_active_user, RoleChecker
from app.rag.vector_store import get_collection
from app.rag.document_processor import process_document
from app.rag.embeddings import get_embeddings_model
from app.rag.search import semantic_search
from app.rag.reranker import rerank_results
from pydantic import BaseModel
from typing import List, Dict, Any
import uuid

router = APIRouter(prefix="/rag", tags=["rag"])

class DocumentIndexRequest(BaseModel):
    document_id: str

class SearchRequest(BaseModel):
    query: str

class SearchResult(BaseModel):
    content: str
    metadata: Dict[str, Any]
    score: float

allow_rag_edit = RoleChecker(["Admin", "Financial Analyst"])

@router.post("/index-document")
def index_document(
    request: DocumentIndexRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(allow_rag_edit)
):
    # Retrieve the document from the database
    doc = db.query(Document).filter(Document.document_id == request.document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
        
    if not doc.file_path:
        raise HTTPException(status_code=400, detail="Document file path is missing")
        
    # Process document into chunks
    chunks = process_document(doc.file_path)
    if not chunks:
        raise HTTPException(status_code=400, detail="Could not extract text or document is empty")
        
    # Generate embeddings
    embeddings_model = get_embeddings_model()
    embeddings = embeddings_model.embed_documents(chunks)
    
    # Insert into ChromaDB
    collection = get_collection()
    
    # We create unique IDs for each chunk based on document ID and chunk index
    ids = [f"{doc.document_id}_chunk_{i}" for i in range(len(chunks))]
    metadatas = [{"document_id": doc.document_id, "chunk_index": i} for i in range(len(chunks))]
    
    collection.add(
        embeddings=embeddings,
        documents=chunks,
        metadatas=metadatas,
        ids=ids
    )
    
    return {
        "message": "Document indexed successfully",
        "document_id": doc.document_id,
        "chunks_indexed": len(chunks)
    }

@router.delete("/remove-document/{document_id}")
def remove_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(allow_rag_edit)
):
    collection = get_collection()
    
    # We query the collection for the document metadata to delete
    # In ChromaDB, delete by metadata filter is supported
    collection.delete(
        where={"document_id": document_id}
    )
    
    return {"message": "Document removed from vector store"}

@router.post("/search", response_model=List[SearchResult])
def search(
    request: SearchRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Semantic search pipeline:
    User Query -> Embedding -> Vector Search -> Top 20 Results -> Reranking -> Top 5 Results
    """
    query = request.query
    if not query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")
        
    # Step 1: Vector Search (Top 20)
    results = semantic_search(query, n_results=20)
    if not results:
        return []
        
    # Step 2: Reranking (Top 5)
    reranked = rerank_results(query, results, top_k=5)
    
    # We map the final results to SearchResult
    final_response = []
    for r in reranked:
        final_response.append(
            SearchResult(
                content=r["content"],
                metadata=r["metadata"],
                score=r["score"]
            )
        )
        
    return final_response

@router.get("/context/{document_id}")
def get_context(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Retrieves the indexed context for a specific document_id.
    """
    collection = get_collection()
    
    results = collection.get(
        where={"document_id": document_id},
        include=["documents", "metadatas"]
    )
    
    if not results or not results["documents"]:
        raise HTTPException(status_code=404, detail="Document context not found")
        
    return {
        "document_id": document_id,
        "chunks": [
            {"content": doc, "metadata": meta} 
            for doc, meta in zip(results["documents"], results["metadatas"])
        ]
    }
