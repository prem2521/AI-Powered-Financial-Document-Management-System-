from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import or_
import uuid
import os
from typing import Optional, List
from app.db.database import get_db
from app.models.document import Document
from app.models.user import User
from app.auth.dependencies import get_current_active_user, RoleChecker
from app.services.storage import save_upload_file, delete_file as remove_local_file
from pydantic import BaseModel
from datetime import datetime

router = APIRouter(prefix="/documents", tags=["documents"])

class DocumentResponse(BaseModel):
    document_id: str
    title: str
    company_name: str
    document_type: str
    uploaded_by: str
    created_at: datetime
    
    class Config:
        from_attributes = True

# Allow Admin and Financial Analyst to upload
allow_upload = RoleChecker(["Admin", "Financial Analyst"])

@router.post("/upload", response_model=DocumentResponse)
def upload_document(
    file: UploadFile = File(...),
    title: str = Form(...),
    company_name: str = Form(...),
    document_type: str = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(allow_upload)
):
    document_id = str(uuid.uuid4())
    file_ext = os.path.splitext(file.filename)[1]
    file_name = f"{document_id}{file_ext}"
    
    file_path = save_upload_file(file, file_name)
    
    new_doc = Document(
        document_id=document_id,
        title=title,
        company_name=company_name,
        document_type=document_type,
        uploaded_by=current_user.username,
        file_path=file_path
    )
    
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)
    
    return new_doc

@router.get("", response_model=List[DocumentResponse])
def get_documents(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    docs = db.query(Document).offset(skip).limit(limit).all()
    return docs

@router.get("/search", response_model=List[DocumentResponse])
def search_documents(
    title: Optional[str] = None,
    company_name: Optional[str] = None,
    document_type: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(10, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    query = db.query(Document)
    if title:
        query = query.filter(Document.title.ilike(f"%{title}%"))
    if company_name:
        query = query.filter(Document.company_name.ilike(f"%{company_name}%"))
    if document_type:
        query = query.filter(Document.document_type == document_type)
        
    docs = query.offset(skip).limit(limit).all()
    return docs

@router.get("/{document_id}", response_model=DocumentResponse)
def get_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc

# Allow Admin and Financial Analyst to delete
allow_delete = RoleChecker(["Admin", "Financial Analyst"])

@router.delete("/{document_id}")
def delete_document(
    document_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(allow_delete)
):
    doc = db.query(Document).filter(Document.document_id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
        
    # Remove from local storage
    if doc.file_path:
        remove_local_file(doc.file_path)
        
    db.delete(doc)
    db.commit()
    
    return {"message": "Document deleted successfully"}
