import os
import shutil
from fastapi import UploadFile

UPLOAD_DIR = "uploaded_documents"

# Ensure the upload directory exists
os.makedirs(UPLOAD_DIR, exist_ok=True)

def save_upload_file(upload_file: UploadFile, file_name: str) -> str:
    """
    Saves the uploaded file to the local disk and returns the file path.
    """
    file_path = os.path.join(UPLOAD_DIR, file_name)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(upload_file.file, buffer)
    return file_path

def delete_file(file_path: str) -> bool:
    """
    Deletes the file from local disk.
    """
    if os.path.exists(file_path):
        os.remove(file_path)
        return True
    return False

def get_file_path(file_name: str) -> str:
    return os.path.join(UPLOAD_DIR, file_name)
