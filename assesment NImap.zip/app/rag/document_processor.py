import fitz  # PyMuPDF
from langchain_text_splitters import RecursiveCharacterTextSplitter
from typing import List, Dict

def extract_text_from_pdf(file_path: str) -> str:
    """
    Extracts text from a PDF file using PyMuPDF.
    """
    try:
        doc = fitz.open(file_path)
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()
        return text
    except Exception as e:
        print(f"Error extracting text from PDF {file_path}: {e}")
        return ""

def extract_text_from_file(file_path: str) -> str:
    """
    Extracts text based on file extension.
    For now, only PDF is robustly supported. Others fallback to plain text read.
    """
    # If the file extension is pdf, try to read as pdf.
    # If it fails, fallback to plain text read (useful for tests using dummy pdf files)
    if file_path.lower().endswith(".pdf"):
        text = extract_text_from_pdf(file_path)
        if text:
            return text

    # Fallback for plain text files (e.g., .txt) or failed pdf reads
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
        return ""

def chunk_text(text: str, chunk_size: int = 1000, chunk_overlap: int = 200) -> List[str]:
    """
    Splits text into chunks using LangChain's RecursiveCharacterTextSplitter.
    """
    if not text.strip():
        return []
        
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    chunks = text_splitter.split_text(text)
    return chunks

def process_document(file_path: str) -> List[str]:
    """
    Full pipeline to extract text and return chunks.
    """
    text = extract_text_from_file(file_path)
    if not text:
        return []
    chunks = chunk_text(text)
    return chunks
