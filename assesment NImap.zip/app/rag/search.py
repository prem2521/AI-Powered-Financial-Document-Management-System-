from typing import List, Dict, Any
from app.rag.vector_store import get_collection
from app.rag.embeddings import get_embeddings_model

def semantic_search(query: str, n_results: int = 20) -> List[Dict[str, Any]]:
    """
    Embeds the query and searches the ChromaDB collection for the top n_results.
    Returns a list of dictionaries containing chunk content and metadata.
    """
    embeddings_model = get_embeddings_model()
    query_embedding = embeddings_model.embed_query(query)
    
    collection = get_collection()
    
    # query collection
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=n_results,
        include=["documents", "metadatas", "distances"]
    )
    
    if not results or not results["documents"] or not results["documents"][0]:
        return []
        
    formatted_results = []
    
    # Chroma returns a list of lists because we can pass multiple query embeddings
    documents = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0] if "distances" in results and results["distances"] else [0] * len(documents)
    
    for doc, meta, dist in zip(documents, metadatas, distances):
        formatted_results.append({
            "content": doc,
            "metadata": meta,
            "distance": dist
        })
        
    return formatted_results
