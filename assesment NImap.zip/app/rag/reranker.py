from sentence_transformers import CrossEncoder
from typing import List, Dict, Any

# Initialize the cross-encoder model
# MS MARCO cross-encoders are standard for reranking passages based on a query
reranker_model = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')

def rerank_results(query: str, results: List[Dict[str, Any]], top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Reranks a list of initial search results using a CrossEncoder.
    Returns the top_k most relevant results.
    """
    if not results:
        return []
        
    # Prepare query-document pairs
    pairs = []
    for res in results:
        pairs.append([query, res["content"]])
        
    # Predict relevance scores
    scores = reranker_model.predict(pairs)
    
    # Associate scores with results
    scored_results = []
    for i, res in enumerate(results):
        scored_results.append({
            "content": res["content"],
            "metadata": res["metadata"],
            "distance": res["distance"], # original vector distance
            "score": float(scores[i])   # reranking score
        })
        
    # Sort by score in descending order (higher score = more relevant)
    scored_results.sort(key=lambda x: x["score"], reverse=True)
    
    # Return top K
    return scored_results[:top_k]
