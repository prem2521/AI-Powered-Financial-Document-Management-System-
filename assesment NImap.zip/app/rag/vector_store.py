import chromadb
from chromadb.config import Settings
import os

CHROMA_DB_DIR = os.environ.get("CHROMA_DB_DIR", "./chroma_db")
COLLECTION_NAME = "financial_documents"

def get_chroma_client():
    client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    return client

def get_collection():
    client = get_chroma_client()
    # Create or get collection
    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"}
    )
    return collection
