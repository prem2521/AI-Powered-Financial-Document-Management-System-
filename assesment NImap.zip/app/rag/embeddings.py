from langchain_huggingface import HuggingFaceEmbeddings

# Initialize the embedding model
# We're using a common, lightweight model suitable for semantic search
embeddings_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

def get_embeddings_model():
    return embeddings_model
