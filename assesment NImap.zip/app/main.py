from fastapi import FastAPI
from app.routers import auth, roles, users, documents, rag
from app.db.database import engine
from app.models.base import Base

# Ensure tables are created (fallback, mostly relying on alembic)
# Base.metadata.create_all(bind=engine)

app = FastAPI(title="Financial Document Management System", version="1.0.0")

app.include_router(auth.router)
app.include_router(roles.router)
app.include_router(users.router)
app.include_router(documents.router)
app.include_router(rag.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to the Financial Document Management System API"}
