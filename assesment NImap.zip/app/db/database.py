from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

import os

# We will use sqlite for local testing if DATABASE_URL is not set.
# The user asked for PostgreSQL, so in a real environment it would be provided via env.
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./sql_app.db")

# For sqlite we need connect_args={"check_same_thread": False}
connect_args = {}
if DATABASE_URL.startswith("sqlite"):
    connect_args["check_same_thread"] = False

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
